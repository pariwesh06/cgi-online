const fs = require('fs'); //synchronous
// const os = require('os');
function read(fileName, callback ) {//private
  var function1 = fs.readFile(fileName, callback );
}

function write(input, fileName){
  fs.writeFile(fileName, input, function(error){
    if(error){
      console.error(error);
      return;
    }
    console.log('wrote successfully');
  });
}
module.exports = {
  read: read,
  write:write
}
// module.exports.read1=read
