const fileOps = require('./file-operations');
// console.log
function postRead(error, data) { //callback, async-api
  if (error) {
    console.error(error);
    return;
  }
  console.log(data.toString());
  //next logic
}
// fileOps.read('input1.txt',postRead );
// fileOps.read('input.txt', postRead);

// fileOps.write('This is some text', 'config.txt');
fileOps.copy();