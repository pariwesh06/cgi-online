var os = require('os'); //import
console.log(os.totalmem());



// var a = 1; //number
// a = 'CGI'; //string
// function add() {
//   console.log(arguments.length);
//   var total = 0;
//   for (var count = 0; count < arguments.length; count++) {
//     total += arguments[count];
//   }
//   return total;
// }
// // function add(){
// //   return 2;
// // }
// var result = add(2, 3, 4, 6);
// console.log(result);



