function print(){
  console.log('hi');
}
// print();
setTimeout(print, 2000);
// function loop(){
//   for(;;){

//   }
// }
// loop();