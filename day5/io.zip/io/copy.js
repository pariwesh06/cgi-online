const fs = require('fs'); //synchronous
const readWrite = require('./read-write');

function copy(source, destination) { //closure
  readWrite.read(source, function (error, data) {
    readWrite.handleError(error);
    readWrite.write(data, destination);
  })
}

module.exports = {
  copy: copy
}