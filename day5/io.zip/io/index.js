const copy1 = require('./copy');
const readWrite1 = require('./read-write');

module.exports = {
  copy: copy1.copy,
  read: readWrite1.read,
  write: readWrite1.write
}
