const fs = require('fs'); //synchronous
function handleError(error) {
  //Logic 
  if (error) {
    // console.error(error);
    throw error;
  }
}
function read(fileName, callback) {//private
  //logic ??
  var function1 = fs.readFile(fileName, callback);
}

function write(input, fileName) {
  fs.writeFile(fileName, input, function (error) {
    handleError(error);
    console.log('wrote successfully');
  });
}

module.exports = {
  read: read,
  write: write,
  handleError:handleError
}