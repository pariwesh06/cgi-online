import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { UserformComponent } from './userform/userform.component';
import {HttpModule} from '@angular/http';
import { UserService } from './services/user.service';
import { Ellipsis } from './pipes/Ellipsis';
@NgModule({ //decorator
  declarations: [
    AppComponent, UserformComponent, Ellipsis
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
