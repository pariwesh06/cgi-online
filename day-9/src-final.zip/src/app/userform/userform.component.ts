import { Component, OnInit } from '@angular/core';
import { observable } from 'rxjs';
import { UserService } from '../services/user.service';
@Component({
  selector: 'userform',
  templateUrl: './userform.component.html',
})

export class UserformComponent {
  private user = { name: 'John' }; //model
  private users: any[] = [];
  private show: boolean = false;
  private order: boolean = false;
  constructor(private service: UserService) {
    this.loadData();
  }
  loadData(){
    const observable = this.service.fetch();
    observable.subscribe(response => this.users = response.json());
  }
  sort() {
    const callback = this.order ? (user1, user2) => user1.age - user2.age : (user1, user2) => user2.age - user1.age;
    this.users.sort(callback);
    this.order = !this.order;
  }
  save() {
    // this.user.name=this.user.name.toUpperCase(); //not a solution
    const observable = this.service.save1(this.user);
    observable.subscribe((response) => {//100-399, success handler
      // this.user._id=response.json();
      this.users.push(Object.assign({}, this.user));
    },
      (error) => {//error handler, 400 to 599
        this.show = true;
      });
  }
  deleteUser(selectedIndex,mongoID) {
    this.service.delete(mongoID).subscribe((response)=>this.users.splice(selectedIndex, 1));
  }
}

// @Component({
//   selector: 'userform',
//   styleUrls: ['./userform.component.css']
// })
// export class UserformComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
