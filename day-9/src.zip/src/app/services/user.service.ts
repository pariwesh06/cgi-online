import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class UserService {
  constructor(private http: Http) { }
  save1(user) {
    const observable = this.http.post('http://localhost:3001/user', user);
    return observable;
  }

  fetch(){
    return this.http.get('http://localhost:3001/user?name=Pariwesh&age=23');
  }
  delete(id){
    return this.http.delete('http://localhost:3001/user/'+id);
  }
}