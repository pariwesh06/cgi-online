const express = require('express');
const io = require('io');
const app = express();
const mongoDAO = require('./dao/mongoDAO');
var cors = require('cors');
app.use(cors());
mongoDAO.initDB();
const bodyParser = require('body-parser'); //middlerware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.post('/user', function (request, response) {
  mongoDAO.insert(request.body);
  response.send(201, 'post called..');
});

app.delete('/user/:id', (request, response)=>{
  mongoDAO.deleteUser(request.params.id, (error, data)=> {
    if(error) throw err;
    response.json(data);
  })
});

app.get('/user', function (request, response) {//closure 
  request.query.age=parseInt(request.query.age);
  mongoDAO.get(request.query, function (error, result) {
    response.send(result);
  });
});

app.get("/user/:id", function (request, response) {
  console.log('query params', request.query.q1);
  console.log(request.headers.accept);
  console.log(request.params.id);
  // response.send(request.query);
  io.read('data.txt', function (error, data) {
    response.send(data.toString());
  })
});

app.listen(3001, function (error) {
  if (error)
    throw error;
  console.log('server started');
});
// for(;;){}
