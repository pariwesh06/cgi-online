
class User{
  constructor(name){

  }

}

const u1 = new User('Ram');
console.log(u1.name)