const express = require('express');
const io = require('io');
const app = express();
const mongoDAO = require('./dao/mongoDAO');

mongoDAO.initDB();
const bodyParser = require('body-parser'); //middlerware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.post('/user', function (request, response) {
  mongoDAO.insert(request.body);
  response.send(201, 'post called..');
});

app.get('user',function(request, response){

});

app.get("/user/:id", function (request, response) {
  console.log('query params', request.query.q1);
  console.log(request.headers.accept);
  console.log(request.params.id);
  // response.send(request.query);
  io.read('data.txt', function (error, data) {
    response.send(data.toString());
  })
});

app.listen(3001, function (error) {
  if (error)
    throw error;
  console.log('server started');
});
// for(;;){}
