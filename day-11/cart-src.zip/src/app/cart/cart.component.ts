import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  products=[];
  product={name:'Laptop', price:600};
  constructor(private service:CartService) { }

  ngOnInit() {
  }
  save(){
    this.service.save(this.product);
  }
}
