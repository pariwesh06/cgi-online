import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { UserService } from '../services/user.service';

@Component({
  selector: 'grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css']
})
export class GridComponent {
  private users: any[] = [];
  private order: boolean = false;
  @Input()
  user;
  constructor(private service: UserService) {
    this.loadData();
  }
  ngOnChanges(changes) {
    console.log(changes);
    
  }
  // @Input()
  saveUser(user) {
    this.users.push(user);
  }
  sort() {
    const callback = this.order ? (user1, user2) => user1.age - user2.age : (user1, user2) => user2.age - user1.age;
    this.users.sort(callback);
    this.order = !this.order;
  }

  loadData() {
    const observable = this.service.fetch();
    observable.subscribe(response => this.users = response.json());
  }
  deleteUser(selectedIndex, mongoID) {
    this.service.delete(mongoID).subscribe((response) => this.users.splice(selectedIndex, 1));
  }
}
