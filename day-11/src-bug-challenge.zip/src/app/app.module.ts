import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { UserformComponent } from './userform/userform.component';
import {HttpModule} from '@angular/http';
import { UserService } from './services/user.service';
import { Ellipsis } from './pipes/Ellipsis';
import { RouterModule, Routes } from '@angular/router';
import { GridComponent } from './grid/grid.component';

const appRoutes: Routes =[
  { path: 'userform1', component: UserformComponent }];  //
@NgModule({ //decorator
  declarations: [
    AppComponent, UserformComponent, Ellipsis, GridComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpModule,
    RouterModule.forRoot(
      appRoutes,
      { enableTracing: false } // <-- debugging purposes only
    )
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
