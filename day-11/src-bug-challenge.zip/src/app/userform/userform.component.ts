import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { observable } from 'rxjs';
import { UserService } from '../services/user.service';
@Component({
  selector: 'userform',
  templateUrl: './userform.component.html',
})

export class UserformComponent {
  user = { name: 'Pariwesh' }; //model
  private show: boolean = false;
  constructor(private service: UserService) {
  }
  save(form1) {
    // this.user.name=this.user.name.toUpperCase(); //not a solution
    const observable = this.service.save1(this.user);
    observable.subscribe((response) => {//100-399, success handler
      this.user._id=response.json();
      console.log(form1.saveUser(this.user));
    },
      (error) => {//error handler, 400 to 599
        this.show = true;
      });
  }
}
