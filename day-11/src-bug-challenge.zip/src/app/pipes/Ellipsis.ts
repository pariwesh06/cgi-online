import { PipeTransform, Pipe } from "@angular/core";

@Pipe({
  name: 'ellipsis123'
})
export class Ellipsis implements PipeTransform {
  transform(value, configuration) {
    console.log(configuration[1]);
    if (value.length > configuration[0])
      return value.substr(0, configuration[0]) + '...';
    else
      return value;
  }
}