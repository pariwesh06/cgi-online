const express = require('express');

const forum = express();

forum
  .get('/healthz', (req, res, next) => {
    res.send({ name: 'forum', status: 'healthy' });
    next();
  })
  .get('/d/:id', (req, res, next) => {
    console.log('testing');
    res.send({ discussion: req.params.id });
    next();
  })
  .listen(process.env.PORT || 1337);

const members = express();

members
  .get('/', (req, res, next) => {
    res.send({ members: [ { name: 'gary', avatar: 'snail' }] });
    next();
  })
  .listen(process.env.PORT2 || 1338);