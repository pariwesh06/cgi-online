const express = require('express');

const forum = express();

forum
  .get('/healthz', (req, res, next) => {
    console.log('called');
    res.send({ name: 'forum', status: 'healthy' });
    next();
  })
  .get('/d/:id', (req, res, next) => {
    console.log('testing');
    res.send({ discussion: req.params.id });
    next();
  });
  forum.listen(process.env.PORT || 1337);

