import { Component, OnInit } from '@angular/core';
import { observable } from 'rxjs';
import { UserService } from '../services/user.service';
@Component({
  selector: 'userform',
  templateUrl: './userform.component.html',
})

export class UserformComponent {
  private user = { fname: 'John' }; //model
  private users: any[] = [];
  constructor(private service: UserService) {

  }
  save() {
    const observable = this.service.save1(this.user);
    observable.subscribe(function (response) {//100-399, success handler
      this.users.push(Object.assign({}, this.user));
    }.bind(this),
      function (error) {//error handler, 400 to 599
        alert('something went wrong' + error);
      }
    );;
  }
  deleteUser(selectedIndex) {
    this.users.splice(selectedIndex, 1);
  }
}

// @Component({
//   selector: 'userform',
//   styleUrls: ['./userform.component.css']
// })
// export class UserformComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
