import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable()
export class UserService {
  constructor(private http: Http) { }
  save1(user) {
    const observable = this.http.post('http://localhost:3001/user123', user);
    return observable;
  }
}